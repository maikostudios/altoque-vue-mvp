<!-- Ejemplo PublicLanding.vue -->
<template>
    <div class="p-4 text-center text-lg">Vista Public Landing</div>
</template>